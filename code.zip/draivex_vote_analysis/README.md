## Vote Analysis and Plotting of DrAiveX Forum Days
### How to use
### On Windows:
* Install Dependencies
    ```sh
        pip install -r requirements.txt
    ```
* Run
    ```sh
        python draivex.py
    ```
### On Linux
* Install Dependencies
    ```sh
        pip3 install -r requirements.txt
    ```
* Run
    ```sh
        python3 draivex.py
    ```
